"""
Python Web Development Techdegree
Project 1 - Number Guessing Game
--------------------------------

For this first project we will be using Workspaces. 

NOTE: If you strongly prefer to work locally on your own computer, you can totally do that by clicking: File -> Download Workspace in the file menu after you fork the snapshot of this workspace.

"""

import random


def start_game():
  print("""           ===================================================
              Hello and welcome to our number guessing game!
           ===================================================
        """)
  r1 = random.randint(1,10)
  counter = 0
  while True:
    try:
       user_guess = int(input("Guess a number between 1 to 10 "))
    except ValueError as err:
        print("{} , you must enter a number.".format(err))
    else:
        if user_guess > r1:
          print("It's Lower")
          counter += 1
        elif user_guess < r1:
          counter += 1
          print("It's Higher")
        elif user_guess == r1:
          counter += 1
          print("Got it!")
          print("It took you {} tries".format(counter))
          counter = 0
          r1 = random.randint(1,10)
          
          #if counter < highest:
           # highest = counter
          #print("The highest score is  >>>{}<<<".format(highest))
          check_user = input("if you want to continue or quit the game enter Y / N : ")
          if check_user.lower() == 'y':
            start_game()
          elif check_user.lower() == 'n':
            print("The End, Hope you enjoyed our game! ")
            break
     
    
  

  
  
  
  
start_game()
